var CHECKSUM = {
build: 'b209de10-eaff-11e6-83d3-cdfcfc553d04'
};
module.exports = CHECKSUM;